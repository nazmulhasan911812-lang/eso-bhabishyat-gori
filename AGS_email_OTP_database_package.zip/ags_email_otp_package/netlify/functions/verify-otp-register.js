const crypto = require("crypto");
const admin = require("firebase-admin");

function initFirebase() {
  if (admin.apps.length) return;
  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKey = (process.env.FIREBASE_PRIVATE_KEY || "").replace(/\\n/g, "\n");
  if (!projectId || !clientEmail || !privateKey) throw new Error("Firebase Admin credentials are not configured.");
  admin.initializeApp({ credential: admin.credential.cert({ projectId, clientEmail, privateKey }), databaseURL: process.env.FIREBASE_DATABASE_URL });
}
function reply(statusCode, body) { return { statusCode, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify(body) }; }

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "POST only" });
  try {
    const body = JSON.parse(event.body || "{}");
    const { email, loginId, password, otp, photo, token } = body;
    // The signed challenge is issued by send-otp and retained by the browser.
    const secret = process.env.OTP_HMAC_SECRET;
    if (!secret || secret.length < 32) return reply(500, { error: "OTP secret not configured." });
    if (!email || !loginId || !password || !otp || !photo) return reply(400, { error: "সব প্রয়োজনীয় তথ্য দিন।" });
    if (String(password).length < 6) return reply(400, { error: "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।" });
    // Browser must send the challenge token; compare HMAC in constant time.
    const challenge = String(body.challenge || "");
    const parts = challenge.split(".");
    if (parts.length !== 2) return reply(400, { error: "OTP সেশন পাওয়া যায়নি। আবার OTP পাঠান।" });
    const expected = crypto.createHmac("sha256", secret).update(parts[0]).digest("base64url");
    const a = Buffer.from(parts[1]), b = Buffer.from(expected);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return reply(400, { error: "OTP যাচাই ব্যর্থ। আবার OTP পাঠান।" });
    const payload = JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8"));
    if (payload.exp < Date.now() || payload.email !== String(email).toLowerCase() || payload.loginId !== loginId || payload.otp !== String(otp)) {
      return reply(400, { error: "OTP ভুল অথবা মেয়াদ শেষ। আবার চেষ্টা করুন।" });
    }
    const digits = String(loginId).replace(/\D/g, "");
    if (String(loginId).trim().toLowerCase() === "admin" || digits === "01647302616" || digits === "8801647302616") {
      return reply(403, { error: "এই আইডি দিয়ে নতুন সাইনআপ করা যাবে না।" });
    }
    if (typeof photo !== "string" || photo.length > 900000) return reply(400, { error: "ছবির আকার বেশি। ছোট ছবি ব্যবহার করুন।" });

    initFirebase();
    const db = admin.database();
    const usersSnap = await db.ref("registeredUsers").once("value");
    let exists = false;
    usersSnap.forEach(ch => {
      const u = ch.val() || {};
      const fields = [u.phone,u.mobile,u.mobileNumber,u.userId,u.userID,u.id,u.memberId,u.memberID,u.username,u.loginId,u.loginID,u.email];
      if (fields.some(v => String(v || "").trim().toLowerCase() === String(loginId).trim().toLowerCase())) exists = true;
    });
    if (exists) return reply(409, { error: "এই আইডি দিয়ে ইতিমধ্যে অ্যাকাউন্ট আছে।" });

    // Keep the legacy login-compatible phone identifier and Staff role.
    const memberId = "PSL-" + crypto.randomInt(100000, 1000000);
    const memberRef = db.ref("members").push();
    const userRef = db.ref("registeredUsers").push();
    const created = Date.now();
    const updates = {};
    updates[`members/${memberRef.key}`] = {
      phone: loginId, id: memberId, name: `সদস্য (${loginId})`, email: String(email).toLowerCase(),
      photo, status: "Pending", designation: "সাধারণ সদস্য", timestamp: created
    };
    updates[`registeredUsers/${userRef.key}`] = {
      phone: loginId, userId: loginId, email: String(email).toLowerCase(),
      // Legacy login currently compares this field; migration to Firebase Auth is a separate change.
      password: String(password), role: "Staff", photo, createdDate: created,
      lastActiveDate: new Date().toLocaleString("bn-BD"), emailVerified: true, emailVerifiedAt: created
    };
    await db.ref().update(updates);
    return reply(200, { ok: true, memberId });
  } catch (e) {
    console.error("verify-otp-register error", e.message);
    return reply(500, { error: "OTP যাচাই বা ডাটাবেইজে সেভ করা যায়নি। Netlify Function logs পরীক্ষা করুন।" });
  }
};
