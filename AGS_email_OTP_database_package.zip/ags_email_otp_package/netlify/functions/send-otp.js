const crypto = require("crypto");
const nodemailer = require("nodemailer");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "POST only" });
  try {
    const { email, loginId } = JSON.parse(event.body || "{}");
    if (!validEmail(email) || typeof loginId !== "string" || !loginId.trim()) {
      return reply(400, { error: "সঠিক ইমেইল ও আইডি দিন।" });
    }
    const secret = process.env.OTP_HMAC_SECRET;
    if (!secret || secret.length < 32) return reply(500, { error: "সার্ভারের OTP secret সেট করা হয়নি।" });

    // Short-lived signed OTP challenge. The code itself is never returned to the browser.
    const otp = String(crypto.randomInt(0, 1000000)).padStart(6, "0");
    const now = Date.now();
    const payload = Buffer.from(JSON.stringify({ email: email.toLowerCase(), loginId, otp, iat: now, exp: now + 10 * 60 * 1000 })).toString("base64url");
    const sig = crypto.createHmac("sha256", secret).update(payload).digest("base64url");
    const token = `${payload}.${sig}`;

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || "smtp.gmail.com",
      port: Number(process.env.SMTP_PORT || 465),
      secure: String(process.env.SMTP_SECURE || "true") === "true",
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
    if (!process.env.SMTP_USER || !process.env.SMTP_PASS) return reply(500, { error: "ইমেইল প্রেরকের SMTP সেটিংস দেওয়া হয়নি।" });

    await transporter.sendMail({
      from: process.env.MAIL_FROM || process.env.SMTP_USER,
      to: email,
      subject: "AGS অ্যাপ — নিরাপদ সাইনআপ OTP",
      text: `আপনার AGS সাইনআপ যাচাই কোড: ${otp}\n\nকোডটি ১০ মিনিটের মধ্যে ব্যবহার করুন। কাউকে কোডটি দেবেন না। আপনি অনুরোধ না করলে এই বার্তাটি উপেক্ষা করুন।`,
      html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:24px;border:1px solid #ddd;border-radius:12px"><h2>AGS অ্যাপ</h2><p>আপনার ৬ সংখ্যার সাইনআপ যাচাই কোড:</p><div style="font-size:32px;font-weight:bold;letter-spacing:8px;padding:16px;background:#f3f4f6;text-align:center">${otp}</div><p>কোডটি ১০ মিনিটের মধ্যে ব্যবহার করুন। কাউকে OTP দেবেন না।</p></div>`
    });
    return reply(200, { ok: true, token });
  } catch (e) {
    console.error("send-otp error", e.message);
    return reply(500, { error: "OTP ইমেইল পাঠানো যায়নি। Netlify-এর SMTP সেটিংস পরীক্ষা করুন।" });
  }
};
function validEmail(v) { return typeof v === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && v.length < 321; }
function reply(statusCode, body) { return { statusCode, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify(body) }; }
