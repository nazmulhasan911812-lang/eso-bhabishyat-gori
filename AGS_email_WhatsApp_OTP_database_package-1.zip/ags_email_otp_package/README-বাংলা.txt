# AGS অ্যাপ — ইমেইল OTP সাইনআপ

## কী রাখা হয়েছে
- মূল AGS HTML-এর ড্যাশবোর্ড, পুরোনো আইডি দিয়ে লগইন, রোল/রিপোর্ট/PDF কোড অক্ষত রাখার চেষ্টা করা হয়েছে।
- নতুন Staff সাইনআপে ৬ সংখ্যার ইমেইল OTP পাঠানো হয়; OTP ১০ মিনিট বৈধ।
- OTP যাচাইয়ের পরে Netlify Function Firebase Admin SDK দিয়ে `members` ও `registeredUsers`-এ তথ্য সেভ করে।
- নতুন সাইনআপে `Staff` রোলই দেওয়া হয়; Admin/Manager/Finance secretary/Information secretary-এর সাইনআপ নেই।

## Netlify-তে আপলোড
1. ZIP extract করুন।
2. ফোল্ডারের সব ফাইল GitHub repository-তে আপলোড করুন (আগের `index.html`-এর backup রাখুন)।
3. Netlify-তে ওই repository deploy করুন।
4. Netlify → Site configuration → Environment variables-এ নিচের variables যোগ করুন।

### ইমেইল (Gmail SMTP)
- `SMTP_HOST` = `smtp.gmail.com`
- `SMTP_PORT` = `465`
- `SMTP_SECURE` = `true`
- `SMTP_USER` = OTP পাঠানোর Gmail ঠিকানা
- `SMTP_PASS` = Gmail-এর **App Password** (সাধারণ Gmail password নয়)
- `MAIL_FROM` = একই Gmail ঠিকানা

Gmail-এ 2-Step Verification চালু করে App Password তৈরি করতে হবে। App Password কাউকে পাঠাবেন না, কোডে লিখবেন না।

### Firebase Admin SDK
Firebase Console → Project settings → Service accounts থেকে service account key তৈরি করুন। JSON ফাইলটি কাউকে দেবেন না। JSON-এর মানগুলো Netlify environment variables-এ বসান:
- `FIREBASE_PROJECT_ID` = JSON-এর `project_id`
- `FIREBASE_CLIENT_EMAIL` = JSON-এর `client_email`
- `FIREBASE_PRIVATE_KEY` = JSON-এর `private_key` (সম্পূর্ণ private key; Netlify-তে multiline/escaped newline অনুযায়ী দিন)
- `FIREBASE_DATABASE_URL` = `https://shirighat-teghoria-ags-default-rtdb.firebaseio.com`

আরেকটি গোপন মান তৈরি করুন:
- `OTP_HMAC_SECRET` = কমপক্ষে ৩২ অক্ষরের একটি এলোমেলো গোপন মান (যেমন password manager দিয়ে generate করুন)।

5. Environment variables যোগ করার পর Netlify-তে **Clear cache and deploy site** / নতুন deploy দিন।
6. মোবাইলে অ্যাপ খুলে Staff নির্বাচন করুন, আইডি/মোবাইল নম্বর ও পাসওয়ার্ড দিন, এরপর ইমেইল চাইলে OTP পাওয়ার ইমেইল দিন। OTP Inbox/Spam-এ দেখুন, কোড লিখুন, প্রোফাইল ছবি আপলোড করে যাচাই করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা/নিরাপত্তা
- এই প্যাকেজে legacy login-এর সঙ্গে সামঞ্জস্য রাখতে পুরোনো `password` field-এ পাসওয়ার্ড রাখার আচরণ বজায় আছে। এটি আদর্শ নিরাপত্তা নয়; Firebase Authentication-এ migration আলাদা কাজ এবং তা না করে এই field মুছে দিলে পুরোনো লগইন ভেঙে যেতে পারে।
- Firebase Realtime Database Rules যদি এখনও `.read: true` / `.write: true` হয়, ডাটাবেইজ অনিরাপদ। এই প্যাকেজে signup save server-side হয়েছে, কিন্তু পুরো অ্যাপের পুরোনো client-side database operations secure করতে Rules আলাদা করে ঠিক করতে হবে।
- বাস্তবে ইমেইল OTP কাজ করবে শুধু Netlify deploy ও সব secret সঠিকভাবে সেট করার পরে। এই পরিবেশে Gmail/Netlify/Firebase live credentials নেই, তাই বাস্তব ইমেইল পাঠানো বা deploy যাচাই করা হয়নি।
- বর্তমান ফাইলের সাইনআপ ফিল্ডটি আইডি/মোবাইল নম্বর হিসেবে ব্যবহৃত হয়; OTP ইমেইল আলাদা prompt-এ চাওয়া হয়। `registeredUsers`-এ `email` যোগ হবে, কিন্তু পুরোনো আইডি/রোল রেকর্ড মুছে বা বদলে দেওয়া হয় না।


## WhatsApp OTP (ঐচ্ছিক)
WhatsApp OTP-এর জন্য Twilio Verify-তে WhatsApp channel/sender সক্রিয় করতে হবে। শুধু HTML ফাইল দিয়ে WhatsApp OTP পাঠানো যায় না।
Netlify Environment variables-এ যোগ করুন:
- `TWILIO_ACCOUNT_SID` = Twilio Account SID
- `TWILIO_AUTH_TOKEN` = Twilio Auth Token (গোপন রাখবেন)
- `TWILIO_VERIFY_SERVICE_SID` = Twilio Verify Service SID

এরপর নতুন deploy দিন। সাইনআপে ১ দিলে ইমেইল OTP, ২ দিলে WhatsApp OTP নির্বাচন করা যাবে। বাংলাদেশি নম্বর 017XXXXXXXX আকারে লিখলেও কোডটি +880 ফরম্যাটে রূপান্তর করার চেষ্টা করবে। WhatsApp নম্বরটি সক্রিয় এবং WhatsApp-এ নিবন্ধিত হতে হবে; Twilio account/service-এ WhatsApp delivery অনুমোদিত থাকতে হবে। Twilio-এর চার্জ/যোগ্যতা/দেশভিত্তিক নিয়ম প্রযোজ্য হতে পারে। Credentials না থাকলে WhatsApp OTP কাজ করবে না।
